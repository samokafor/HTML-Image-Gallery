
function openFullImg(pic) {
    var modal = document.createElement('div');
    modal.className = 'modal';

    var img = document.createElement('img');
    img.src = pic;

    var closeButton = document.createElement('span');
    closeButton.innerHTML = '&times;';
    closeButton.className = 'close';
    closeButton.addEventListener('click', function () {
        document.body.removeChild(modal);
    });

    modal.appendChild(closeButton);
    modal.appendChild(img);
    document.body.appendChild(modal);

    modal.addEventListener('mousedown', function () {
        document.body.removeChild(modal);
    });
}

function downloadGallery() {
    var images = document.querySelectorAll('.image-gallery img');
    images.forEach(function (img, index) {
        var link = document.createElement('a');
        link.href = img.src;
        link.download = 'image_' + (index + 1) + '.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
}
